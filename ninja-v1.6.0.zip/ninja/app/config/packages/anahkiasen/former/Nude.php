<?php

return array(

	// HTML markup and classes used by the "Nude" framework for icons
	'icon' => array(

		'tag' => 'i',
		'set' => null,
		'prefix' => 'icon',

	),

);