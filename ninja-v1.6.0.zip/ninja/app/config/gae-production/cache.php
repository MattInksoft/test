<?php

return array(

	'driver' => 'memcached',

);