<?php

return array(

	'debug' => true,

	'manifest' => 'gs://invoice-ninja/meta',
	
);