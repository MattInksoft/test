{{ nl2br($text) }}
