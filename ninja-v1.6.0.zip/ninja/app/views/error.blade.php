@extends('public.header')

@section('content')

<p>&nbsp;<p>
<p>&nbsp;<p>

<div class="well">
  <div class="container" style="min-height:400px">
	<h3>{{ $error }}</h3>
  Looks like something went wrong.<br/>
  If you'd like help please email us at contact@invoiceninja.com.
</div>
</div>

<p>&nbsp;<p>
<p>&nbsp;<p>


@stop