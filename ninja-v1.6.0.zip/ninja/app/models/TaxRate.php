<?php

class TaxRate extends EntityModel
{

}