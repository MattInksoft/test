<?php

class InvoiceDesign extends Eloquent
{
  public $timestamps = false;
  protected $softDelete = false;  
}
