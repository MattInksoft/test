<?php

class PaymentTerm extends Eloquent
{
	public $timestamps = false;
	protected $softDelete = false;
}