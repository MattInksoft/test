<?php

class Theme extends Eloquent
{
	public $timestamps = false;
	protected $softDelete = false;
}