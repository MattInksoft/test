<?php

class License extends Eloquent
{
  public $timestamps = true;
  protected $softDelete = true;  
}