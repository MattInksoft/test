<?php

class DatetimeFormat extends Eloquent
{
	public $timestamps = false;
	protected $softDelete = false;
}