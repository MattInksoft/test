<?php

class Subscription extends Eloquent
{
  public $timestamps = true;
  protected $softDelete = true;  
}