<?php

class Affiliate extends Eloquent
{
  public $timestamps = true;
  protected $softDelete = true;  
}