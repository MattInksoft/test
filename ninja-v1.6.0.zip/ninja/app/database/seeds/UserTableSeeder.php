<?php

class UserTableSeeder extends Seeder
{

	public function run()
	{

	}

}