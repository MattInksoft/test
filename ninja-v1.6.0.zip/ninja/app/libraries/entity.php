<?

class Entity
{
	public $id;
	public $type;
}

